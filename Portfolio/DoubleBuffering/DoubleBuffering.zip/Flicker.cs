﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DoubleBuffering
{
    public partial class Flicker : Form
    {
        Rectangle rect;
        int x = 0;
        int y = 200;
        int saved_x = 1;
        int saved_y = 1;

        public Flicker()
        {
            InitializeComponent();
            // Position the form
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(0, 0);
            // Size the form
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.Width = 400;
            this.Height = 400;
            // Create the small rectangle objects using client (form) coordinates

            rect = new Rectangle(x, y, 50, 50);
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            // Create a black pen and white and a red brush
            Pen blackPen = new Pen(Color.Black);
            Brush redBrush = new SolidBrush(Color.Red);
            Brush whiteBrush = new SolidBrush(Color.White);
            // Define a font for writing
            Font myFont = new System.Drawing.Font("Helvetica", 9);

            Bitmap backBuf = new Bitmap(this.Width, this.Height);

            while (true)
            {
                Graphics g2 = Graphics.FromImage(backBuf);
                // Define and fill large rectangle background 
                g2.FillRectangle(whiteBrush, 0, 0, 400, 400);
                // Redefine the position of the small rectangle
                rect.Location = new Point(x, y);
                // Draw small rectangle in new position 
                g2.DrawRectangle(blackPen, rect);
                // Display message always in same position
                g2.DrawString("Moving rectangle", myFont, redBrush, 150, 150);

                g.DrawImage(backBuf, 0, 0);

                x += saved_x;
                y += saved_y;

                if (x <= 0 || x >= 335)
                    saved_x = -saved_x;

                if (y <= 0 || y >= 315)
                    saved_y = -saved_y;

                Thread.Sleep(10);
            }
        }
    }
}
