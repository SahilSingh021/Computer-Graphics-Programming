﻿
public class Matrix2D
{
    private int[,] matrix;

    public Matrix2D(int[,] matrix)
    {
        this.matrix = matrix;
    }

    public int[,] GetMatrix()
    {
        return matrix;
    }

    public void DisplayContents()
    {
        for (int i = 0; i < matrix.GetLength(0); i++)
        {
            for (int j = 0; j < matrix.GetLength(1); j++)
            {
                Console.Write(matrix[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}

public class MatrixMultiplier
{
    public static Matrix2D Multiplies(Matrix2D a, Matrix2D b)
    {
        int[,] matrixA = a.GetMatrix();
        int[,] matrixB = b.GetMatrix();

        int[,] result = new int[2, 2];

        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 2; j++)
            {
                result[i, j] = matrixA[i, 0] * matrixB[0, j] +
                               matrixA[i, 1] * matrixB[1, j];
            }
        }

        return new Matrix2D(result);
    }
}

public class Testing
{
    public static void Main()
    {
        int[,] arrayA = { { 1, 2 }, { 3, 4 } };
        int[,] arrayB = { { 5, 6 }, { 7, 8 } };

        Matrix2D matA = new Matrix2D(arrayA);
        Matrix2D matB = new Matrix2D(arrayB);

        Console.WriteLine("Matrix A:");
        matA.DisplayContents();

        Console.WriteLine("Matrix B:");
        matB.DisplayContents();

        Matrix2D result = MatrixMultiplier.Multiplies(matA, matB);

        Console.WriteLine("Result of A x B:");
        result.DisplayContents();

        Console.WriteLine("\nPress any key to exit...");
        Console.ReadKey();
    }
}