﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rotation
{
    public partial class Transforms : Form
    {
        public Transforms()
        {
            InitializeComponent();
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            // Specify form located top left origin of screen
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(0, 0);
            this.Width = 500;
            this.Height = 500;
            this.BackColor = Color.White;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Create a pen for drawing
            Pen blackPen = new Pen(Color.Black);

            // Define a font and a brush for writing
            Font myFont = new System.Drawing.Font("Helvetica", 9);
            Brush blackwriter = new SolidBrush(System.Drawing.Color.Black);

            // Create and draw a rectangle
            Rectangle rect = new Rectangle(250, 50, 50, 100);
            g.DrawRectangle(blackPen, rect);
            g.DrawString("1st pos", myFont, blackwriter, rect.Left, rect.Bottom);
            // Record center of rectangle
            PointF center = new PointF(rect.X + (rect.Width / 2.0F),
                                                             rect.Y + (rect.Height / 2.0F));

            // Implement transformations using the Matrix class
            Matrix myMatrix = new Matrix();

            // Rotate clockwise around world origin upper left 0, 0 
            myMatrix.Rotate(30);
            g.Transform = myMatrix;
            g.DrawRectangle(blackPen, rect);
            g.DrawString("2nd pos", myFont, blackwriter, rect.Right, rect.Bottom);

            // Calculate where new location of rotated point will be 
            PointF newcenter = Tmatrix.matrixRotate(30, center);

            // Rotate clockwise around center of previously rotated rectangle
            myMatrix.RotateAt(30, newcenter, MatrixOrder.Append);
            g.Transform = myMatrix;
            g.DrawRectangle(blackPen, rect);
            g.DrawString("3rd pos", myFont, blackwriter, rect.Right, rect.Top);

            // Reset transformation to be a translation
            myMatrix.Reset();
            myMatrix.Translate(100.0F, 0.0F);
            g.Transform = myMatrix;
            g.DrawRectangle(blackPen, rect);
            g.DrawString("4th pos", myFont, blackwriter, rect.Left, rect.Bottom);


            Rectangle testRect = new Rectangle(200, 30, 30, 80);
            PointF testRectCenter = new PointF(testRect.X + (testRect.Width / 2.0F), testRect.Y + (testRect.Height / 2.0F));
            PointF testRectRotation = Tmatrix.matrixRotate(40, testRectCenter);

            Matrix testRectMatrix = new Matrix();
            testRectMatrix.Rotate(40);
            g.Transform = testRectMatrix;
            g.DrawRectangle(blackPen, testRect);

            testRectMatrix.RotateAt(40, testRectRotation, MatrixOrder.Append);
            g.Transform = testRectMatrix;
            g.DrawRectangle(blackPen, testRect);
        }
    }
}
