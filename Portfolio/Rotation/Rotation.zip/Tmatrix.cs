﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rotation
{
    internal class Tmatrix
    {
        public static PointF matrixRotate(float angle, PointF point)
        {
            float radians = angle * (float)(Math.PI / 180.0);

            PointF rotatedPoint = new PointF();
            rotatedPoint.X = point.X * (float)Math.Cos(radians) - point.Y * (float)Math.Sin(radians);
            rotatedPoint.Y = point.X * (float)Math.Sin(radians) + point.Y * (float)Math.Cos(radians);

            return rotatedPoint;
        }
    }
}
