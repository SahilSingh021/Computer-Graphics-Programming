﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace LineAndPoints
{
    public partial class LineAndPoints : Form
    {
        public LineAndPoints()
        {
            this.AutoScaleMode = AutoScaleMode.Font;
            this.ClientSize = new Size(800, 450);
            this.Text = "Line and Points";
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            Graphics g = e.Graphics;

            using (Pen blackPen = new Pen(Color.Black, 2))
            {
                // Points used to define the shapes
                Point[] points =
                {
                    new Point(50, 50),
                    new Point(250, 50),
                    new Point(250, 150),
                    new Point(50, 150),

                    new Point(250, 50),
                    new Point(400, 50),
                    new Point(400, 100),
                    new Point(250, 100),

                    new Point(50, 150),
                    new Point(400, 150),
                    new Point(400, 250),
                    new Point(50, 250)
                };

                // Each row stores the indexes of two points to join with a line
                int[,] lines =
                {
                    { 0, 1 },
                    { 1, 2 },
                    { 2, 3 },
                    { 3, 0 },

                    { 4, 5 },
                    { 5, 6 },
                    { 6, 7 },
                    { 7, 4 },

                    { 8, 9 },
                    { 9, 10 },
                    { 10, 11 },
                    { 11, 8 }
                };

                // Draw all lines based on the point pairs above
                for (int i = 0; i < lines.GetLength(0); i++)
                {
                    int startIndex = lines[i, 0];
                    int endIndex = lines[i, 1];

                    g.DrawLine(blackPen, points[startIndex], points[endIndex]);
                }
            }
        }
    }
}